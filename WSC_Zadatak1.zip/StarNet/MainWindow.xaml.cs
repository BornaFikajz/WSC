﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StarNet
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string serverPath = @"Data Source=DESKTOP-VUVMMFH;Initial Catalog=StarNetDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public MainWindow()
        {
            InitializeComponent();
           
        }

        
        public void btnImport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                fnLoadCSV();
            }
            catch (Exception)
            {
                throw;
            }


        }

                                            //SEARCH i READ CSV FILE-A
         void fnLoadCSV()
        {
            DataTable dataTable = new DataTable();

            try
            {
                Microsoft.Win32.OpenFileDialog lObjFileDlge = new Microsoft.Win32.OpenFileDialog();
                lObjFileDlge.Filter = "CSV Files|*.csv";
                lObjFileDlge.FilterIndex = 1;
                lObjFileDlge.Multiselect = false;
                string fName = "";
                bool? lBlnUserclicked = lObjFileDlge.ShowDialog();
                if (lBlnUserclicked != null || lBlnUserclicked == true)
                {
                    fName = lObjFileDlge.FileName;
                }
                if (System.IO.File.Exists(fName) == true)
                {
                    DataColumn proper = new DataColumn("proper", typeof(string));
                    DataColumn dist = new DataColumn("dist", typeof(double));
                    DataColumn mag = new DataColumn("mag", typeof(double));

                    //DataTable dataTable = new DataTable();
                    dataTable.Columns.Add(proper);
                    dataTable.Columns.Add(dist);
                    dataTable.Columns.Add(mag);

                    StreamReader lObjStreamReader = new StreamReader(fName);
                    string[] totalData = new string[File.ReadAllLines(fName).Length];
                    totalData = lObjStreamReader.ReadLine().Split(',');
                    while (!lObjStreamReader.EndOfStream)
                    {
                        totalData = lObjStreamReader.ReadLine().Split(',');
                        if (totalData[6] != "")
                        {
                            dataTable.Rows.Add(totalData[6], totalData[9], totalData[13]);
                        }

                        grdData.ItemsSource = dataTable.DefaultView;
                        lObjStreamReader.Close();

                    }

                }
            }


            catch (Exception)
            {
                throw;
            }


        }

         private void btnSaveChanges_Click(object sender, RoutedEventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(serverPath))
            {
                //ATTEMPT 2 Bulk copy iz DataTablea
                sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("EditStar", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                using (var command = new SqlCommand("InsertStar") { CommandType = CommandType.StoredProcedure })
                {
                    var dt = new DataTable();
                    command.Parameters.Add(new SqlParameter("@udtStar1", dataTable));
                    sqlCmd.ExecuteNonQuery();
                }


                                    //ATTEMPT 1 Upload iz DataGrida
                                    //radi do i=22
                /* int redovi = grdData.Items.Count;
                 for (int i = 0; i<redovi; i++)
                 {



                 TextBlock x = grdData.Columns[0].GetCellContent(grdData.Items[i])as TextBlock;
                 TextBlock xz = grdData.Columns[1].GetCellContent(grdData.Items[i])as TextBlock;
                 TextBlock xk = grdData.Columns[2].GetCellContent(grdData.Items[i]) as TextBlock;
                 string NAZIV = (string)Convert.ToString(x.Text);
                 double DISTANCA = (double)Convert.ToDouble(xz.Text);
                 double MAGNITUDA = (double)Convert.ToDouble(xk.Text);
                 sqlCmd.Parameters.AddWithValue("@proper", NAZIV);
                 sqlCmd.Parameters.AddWithValue("@distance", DISTANCA);
                 sqlCmd.Parameters.AddWithValue("@magnitude", MAGNITUDA);
                 sqlCmd.ExecuteNonQuery();
                 sqlCmd.Parameters.Clear();





                 }*/
                MessageBox.Show("Job's done");




               


            }
        }
    }
}
        
    

